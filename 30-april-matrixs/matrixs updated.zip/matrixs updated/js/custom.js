
// 25 April 2020 loader start code js

$(document).ready(function () {
	$(".loader").fadeOut(3000);
	// $(window).load(function() { 
	// 	alert();
	//     // $(".loader").fadeOut(1000);
	// });
}); 
// code for js counceling page hide/show
// 30-april-2020

var url      = window.location.href; 
var arr = url.split('/'); 
if(arr[arr.length - 1] == "counseling.html"){
$(document).ready(function() {
	var s = $(".clearHeader")
	var pos = s.position();					   
	$(window).scroll(function() {
		var windowpos = $(window).scrollTop();
		if ($(document).scrollTop() > 6000) {
			// s.addClass("stick");
			$('.clearHeader').fadeOut('slow');
		} else {
			$('.clearHeader').fadeIn('slow');
		}
	});
});
}
// code for js healing page hide/show

if(arr[arr.length - 1] == "healing.html"){
	// alert();
$(document).ready(function() {
	var s = $(".clearHeader")
	var pos = s.position();					   
	$(window).scroll(function() {
		var windowpos = $(window).scrollTop();
		if ($(document).scrollTop() > 3800) {
			$('.clearHeader').fadeOut('slow');
		} else {
			// s.removeClass("stick");	
			$('.clearHeader').fadeIn('slow');
		}
	});
});
}
// code for js chakra page hide/show

if(arr[arr.length - 1] == "chakra.html"){
$(document).ready(function() {
	var s = $(".clearHeader")
	var pos = s.position();					   
	$(window).scroll(function() {
		var windowpos = $(window).scrollTop();
		if ($(document).scrollTop() > 3200) {
			$('.clearHeader').fadeOut('slow');
		} else {
			// s.removeClass("stick");	
			$('.clearHeader').fadeIn('slow');
		}
	});
});
}